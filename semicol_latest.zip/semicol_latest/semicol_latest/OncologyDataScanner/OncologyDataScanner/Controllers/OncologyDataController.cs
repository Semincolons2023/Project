﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OncologyDataScanner.DatabaseService;
using OncologyDataScanner.Model;
using OncologyDataScanner.Utility;
using System.Web.Http.Cors;

namespace OncologyDataScanner.Controllers
{
    [Route("OncologyDataScanner/[controller]")]
    [ApiController]
    
    public class OncologyDataController : ControllerBase
    {
        private readonly PatientService _patientService;

        public OncologyDataController(PatientService patientService)
        {
            _patientService = patientService;
        }

        //[HttpGet("{id:}")]
        //public async Task<List<PatientRecords>> GetRecordsById(string id) => await _patientService.GetRecordsAsync(id);

        //[HttpGet]
        //public async Task<ActionResult<PatientRecords>> GetRecordById(string id)
        //{
        //    var patientRecord = await _patientService.GetAsync(id);
        //    if ((patientRecord is null))
        //    {
        //        return NotFound();
        //    }

        //    return patientRecord;
        //}

        //[HttpGet("GetRecords")]
        //public async Task<List<PatientRecords>> GetRecordsByFilterConditions(string conditions) => await _patientService.GetRecordsByFilterConditionAsync(conditions);
        //[System.Web.Http.Cors.EnableCors(origins: "http://localhost:3006/", headers: "*", methods: "*")]
        [HttpPost("GetRecordsWithConditions")]
        public List<PatientRecords> GetRecordsWithConditions([FromBody]object value)
        { 
            return _patientService.GetListOfPatientsWithMatchingCriteria(value);
        }




    }
}
