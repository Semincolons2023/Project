﻿namespace OncologyDataScanner.Utility
{
    public interface IDataScanner
    {
        string GetListOfPatientsWithMatchingCriteria(string input);
    }
}
