﻿using OncologyDataScanner.Database;
using OncologyDataScanner.Model;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System.Runtime;
using OncologyDataScanner.Utility;
using System.Text.Json;
using MongoDB.Bson.IO;
using Newtonsoft.Json;
using System.Text.RegularExpressions;

namespace OncologyDataScanner.DatabaseService
{
    public class PatientService
    {
        private readonly IMongoCollection<PatientRecords> _patientRecordCollection;

        IMongoCollection<PatientRecords> _filterPatientCollection;
        List<KeyValuePair<string, string>> filterConditions;

        List<KeyValuePair<string, string>> inclusionCriteria = new List<KeyValuePair<string, string>>();
        List<KeyValuePair<string, string>> exclusionCriteria = new List<KeyValuePair<string, string>>();
        public PatientService(IOptions<DatabaseSettings> db)
        {
            _patientRecordCollection = new MongoClient(db.Value.ConnectionString)
                .GetDatabase(db.Value.Database)
                .GetCollection<PatientRecords>(db.Value.Collection);
        }



        /// <summary>
        /// Retrieves all the documents from the Database and displays it
        /// </summary>
        /// <returns></returns>
        public async Task<List<PatientRecords>> GetAsync() =>
            await _patientRecordCollection.Find(_ => true).ToListAsync();

        /// <summary>
        /// Retrieves the document from database which matches with the input field and value
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<PatientRecords> GetAsync(string id) =>
            await _patientRecordCollection.Find(x => x.Patient_ID == id).FirstOrDefaultAsync();

        public IMongoCollection<PatientRecords> Get_patientRecordCollection()
        {
            return _patientRecordCollection;
        }

        public async Task<List<PatientRecords>> GetRecordsAsync(string type) =>
           await _patientRecordCollection.Find(x => x.Patient_ID == type).ToListAsync();

        // public async Task<List<PatientRecords>> GetRecordsWithMultipleFilterConditionAsync(List<KeyValuePair<string, string>> filterconditions) => await GetRecordsFilterBasedOnValue(filterconditions).ToList();

        public async Task<List<PatientRecords>> GetRecordsByFilterConditionAsync(string type) =>
           await _patientRecordCollection.Find(x => x.Patient_ID == type).ToListAsync();

        private List<PatientRecords> GetRecordsFilterBasedOnValue(List<KeyValuePair<string, string>> inclusionCondition, List<KeyValuePair<string, string>> exclusionCondition)
        {
            List<PatientRecords> _filteredtCollection = new List<PatientRecords>();
            //Inclusion Criteria filters
            if (inclusionCondition.Count > 0)
            {
                _filteredtCollection = _patientRecordCollection.Find(_ => true).ToList();
                foreach (KeyValuePair<string, string> columnValuePair in inclusionCondition)
                {
                    List<PatientRecords> _tempCollection = new List<PatientRecords>();
                    string InputColumnName =  Regex.Replace(Regex.Replace(columnValuePair.Key, @"\s+", "").ToUpper(), @"[^0-9a-zA-Z]+", "");
                    switch (InputColumnName)
                    {
                        case "AGEINT":
                        case "AGE":
                            //Age
                            _tempCollection = _filteredtCollection.Where(x => x.Diagnosis_Age == columnValuePair.Value).ToList();
                            break;

                        case "CANCERTYPE":
                            //Cancer Type
                            _tempCollection = _filteredtCollection.Where(x => x.Cancer_Type == columnValuePair.Value).ToList();

                            break;

                        case "STAGE":
                            //Neoplasm Disease Stage American Joint Committee on Cancer Code
                            _tempCollection = _filteredtCollection.Where(x => x.Neoplasm_Disease_Stage_American_Joint_Committee_on_Cancer_Code == columnValuePair.Value).ToList();
                            break;

                        case "EGFR":
                            //EGFR Mutation Status
                            _tempCollection = _filteredtCollection.Where(x => x.EGFR_driver == columnValuePair.Value).ToList();
                            break;

                        case "KARNOFSKYSCORE":
                            //Karnofsky Performance Score
                            _tempCollection = _filteredtCollection.Where(x => x.Karnofsky_Performance_Score == columnValuePair.Value).ToList();
                            break;

                        case "SUBTYPE":
                            //Subtype
                            _tempCollection = _filteredtCollection.Where(x => x.Subtype == columnValuePair.Value).ToList();
                            break;
                        case "METASTASISSTAGECODE":
                        case "PRESENCEOFMETASTASIS":
                            //American Joint Committee on Cancer Metastasis Stage Code
                            _tempCollection = _filteredtCollection.Where(x => x.American_Joint_Committee_on_Cancer_Metastasis_Stage_Code == columnValuePair.Value).ToList();
                            break;

                        case "TUMORSTAGECODE":
                            //American Joint Committee on Cancer Tumor Stage Code
                            _tempCollection = _filteredtCollection.Where(x => x.American_Joint_Committee_on_Cancer_Tumor_Stage_Code == columnValuePair.Value).ToList();
                            break;

                        case "LYMPHNODESTAGECODE":
                            //Neoplasm Disease Lymph Node Stage American Joint Committee on Cancer Code
                            _tempCollection = _filteredtCollection.Where(x => x.Neoplasm_Disease_Lymph_Node_Stage_American_Joint_Committee_on_Cancer_Code == columnValuePair.Value).ToList();
                            break;

                        case "ECOG":
                            //ECOG
                            _tempCollection = _filteredtCollection.Where(x => x.ECOG == columnValuePair.Value).ToList();
                            break;

                        case "GENDER":
                            //Sex
                            _tempCollection = _filteredtCollection.Where(x => x.Sex == columnValuePair.Value).ToList();
                            break;

                        case "ALK":
                            //ALK Translocation Status
                            _tempCollection = _filteredtCollection.Where(x => x.ALK_Translocation_Status == columnValuePair.Value).ToList();
                            break;

                        default:
                            break;
                    }
                    if (_tempCollection.Count > 0)
                    {
                        _filteredtCollection = _tempCollection;
                    }

                }
            }
            //Exclusion Criteria filters
            if (exclusionCondition.Count > 0)
            {
                foreach (KeyValuePair<string, string> columnValuePair in exclusionCondition)
                {
                    List<PatientRecords> _tempCollection = new List<PatientRecords>();
                    string InputColumnName = InputColumnName = Regex.Replace(Regex.Replace(columnValuePair.Key, @"\s+", "").ToUpper(), @"[^0-9a-zA-Z]+", "");
                    switch (InputColumnName)
                    {
                        case "AGEINT":
                        case "AGE":
                            //Age
                            _tempCollection = _filteredtCollection.Where(x => x.Diagnosis_Age != columnValuePair.Value).ToList();
                            break;

                        case "CANCERTYPE":
                            //Cancer Type
                            _tempCollection = _filteredtCollection.Where(x => x.Cancer_Type != columnValuePair.Value).ToList();

                            break;

                        case "STAGE":
                            //Neoplasm Disease Stage American Joint Committee on Cancer Code
                            _tempCollection = _filteredtCollection.Where(x => x.Neoplasm_Disease_Stage_American_Joint_Committee_on_Cancer_Code != columnValuePair.Value).ToList();
                            break;

                        case "EGFR":
                            //EGFR Mutation Status
                            _tempCollection = _filteredtCollection.Where(x => x.EGFR_driver != columnValuePair.Value).ToList();
                            break;

                        case "KARNOFSKYSCORE":
                            //Karnofsky Performance Score
                            _tempCollection = _filteredtCollection.Where(x => x.Karnofsky_Performance_Score != columnValuePair.Value).ToList();
                            break;

                        case "SUBTYPE":
                            //Subtype
                            _tempCollection = _filteredtCollection.Where(x => x.Subtype != columnValuePair.Value).ToList();
                            break;
                        case "METASTASISSTAGECODE":
                        case "PRESENCEOFMETASTASIS":
                            //American Joint Committee on Cancer Metastasis Stage Code
                            _tempCollection = _filteredtCollection.Where(x => x.American_Joint_Committee_on_Cancer_Metastasis_Stage_Code != columnValuePair.Value).ToList();
                            break;

                        case "TUMORSTAGECODE":
                            //American Joint Committee on Cancer Tumor Stage Code
                            _tempCollection = _filteredtCollection.Where(x => x.American_Joint_Committee_on_Cancer_Tumor_Stage_Code != columnValuePair.Value).ToList();
                            break;

                        case "LYMPHNODESTAGECODE":
                            //Neoplasm Disease Lymph Node Stage American Joint Committee on Cancer Code
                            _tempCollection = _filteredtCollection.Where(x => x.Neoplasm_Disease_Lymph_Node_Stage_American_Joint_Committee_on_Cancer_Code != columnValuePair.Value).ToList();
                            break;

                        case "ECOG":
                            //ECOG
                            _tempCollection = _filteredtCollection.Where(x => x.ECOG != columnValuePair.Value).ToList();
                            break;

                        case "GENDER":
                            //Sex
                            _tempCollection = _filteredtCollection.Where(x => x.Sex != columnValuePair.Value).ToList();
                            break;

                        case "ALK":
                            //ALK Translocation Status
                            _tempCollection = _filteredtCollection.Where(x => x.ALK_Translocation_Status != columnValuePair.Value).ToList();
                            break;

                        default:
                            break;
                    }
                    if (_tempCollection.Count > 0)
                    {
                        _filteredtCollection = _tempCollection;
                    }

                }
            }
            return _filteredtCollection;
        }


        public List<PatientRecords> GetListOfPatientsWithMatchingCriteria(string input)
        {
            ConverStringToCriterias(input);
            
            return GetRecordsFilterBasedOnValue(inclusionCriteria,exclusionCriteria);
        }

        public void ConverStringToCriterias(string input)
        {
            Regex r = new Regex(@"\[(.*?)\]");
            var strToMatch = input;
            var matched = r.Matches(strToMatch);
            if (matched.Count > 0) 
            {
                string inclusion = matched[0].Value;
                string exclusion = matched[1].Value;
                if (inclusion.Contains("[{\"inclusion\":"))
                {
                    inclusion= inclusion.Replace("[{\"inclusion\":", "");
                    inclusion = inclusion.Replace("[", "");
                    inclusion = inclusion.Replace("]", "");
                    List<string> inclusionstringSet = inclusion.Split(',').ToList();
                    foreach (var item in inclusionstringSet)
                    {
                        item.Split(":");
                        string key = item.Split(":")[0].ToString().Replace("{", "");
                        string value = item.Split(":")[1].ToString().Replace("}", "");
                        inclusionCriteria.Add(new KeyValuePair<string, string>(key, value));
                    }
                }
                
                    exclusion = exclusion.Replace("[", "");
                    exclusion = exclusion.Replace("]", "");
                    List<string> exclusionstringSet = exclusion.Split(',').ToList();
                foreach (var item in exclusionstringSet)
                {
                    item.Split(":");
                    string key = item.Split(":")[0].ToString().Replace("{","");
                    string value = item.Split(":")[1].ToString().Replace("}", "");
                    exclusionCriteria.Add(new KeyValuePair<string, string>(key, value));
                }
            }
        }
    }
}
