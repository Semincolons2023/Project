﻿using OncologyDataScanner.Database;
using OncologyDataScanner.Model;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System.Runtime;
using OncologyDataScanner.Utility;
using System.Text.Json;

namespace OncologyDataScanner.DatabaseService
{
    public class PatientService
    {
        private readonly IMongoCollection<PatientRecords> _patientRecordCollection;

        IMongoCollection<PatientRecords> _filterPatientCollection;
        List<KeyValuePair<string, string>> filterConditions;
        public PatientService(IOptions<DatabaseSettings> db)
        {
            _patientRecordCollection = new MongoClient(db.Value.ConnectionString)
                .GetDatabase(db.Value.Database)
                .GetCollection<PatientRecords>(db.Value.Collection);

            //filterConditions = CreateMokData();
            
            //GetListOfPatientsWithMatchingCriteria(@"D:\\Divyansh\\Oncology Semicolon\\CompleteData\\SampleJsonInputFile.json");
            //GetRecordsFilterBasedOnValue(filterConditions);
        }

       

        /// <summary>
        /// Retrieves all the documents from the Database and displays it
        /// </summary>
        /// <returns></returns>
        public async Task<List<PatientRecords>> GetAsync() =>
            await _patientRecordCollection.Find(_ => true).ToListAsync();

        /// <summary>
        /// Retrieves the document from database which matches with the input field and value
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<PatientRecords> GetAsync(string id) =>
            await _patientRecordCollection.Find(x => x.Patient_ID == id).FirstOrDefaultAsync();

        public IMongoCollection<PatientRecords> Get_patientRecordCollection()
        {
            return _patientRecordCollection;
        }

        public async Task<List<PatientRecords>> GetRecordsAsync(string type) =>
           await _patientRecordCollection.Find(x => x.Patient_ID == type).ToListAsync();

        // public async Task<List<PatientRecords>> GetRecordsWithMultipleFilterConditionAsync(List<KeyValuePair<string, string>> filterconditions) => await GetRecordsFilterBasedOnValue(filterconditions).ToList();

        public async Task<List<PatientRecords>> GetRecordsByFilterConditionAsync(string type) =>
           await _patientRecordCollection.Find(x => x.Patient_ID == type).ToListAsync();

        private List<PatientRecords> GetRecordsFilterBasedOnValue(List<KeyValuePair<string, string>> filterconditions)
        {
            List<PatientRecords> _filteredtCollection = new List<PatientRecords>();
            if (filterconditions.Count > 0)
            {
                _filteredtCollection = _patientRecordCollection.Find(_ => true).ToList();
                foreach (KeyValuePair<string, string> columnValuePair in filterconditions)
                {
                    List<PatientRecords> _tempCollection = new List<PatientRecords>();
                    string InputColumnName = System.Text.RegularExpressions.Regex.Replace(columnValuePair.Key, @"\s+", "").ToUpper();
                    switch (InputColumnName)
                    {
                        case "AGEINT":
                        case "AGE":
                            //Age
                            _tempCollection = _filteredtCollection.Where(x => x.Diagnosis_Age == columnValuePair.Value).ToList();
                            break;

                        case "CANCERTYPE":
                            //Cancer Type
                            _tempCollection = _filteredtCollection.Where(x => x.Cancer_Type == columnValuePair.Value).ToList();

                            break;

                        case "STAGE":
                            //Neoplasm Disease Stage American Joint Committee on Cancer Code
                            _tempCollection = _filteredtCollection.Where(x => x.Neoplasm_Disease_Stage_American_Joint_Committee_on_Cancer_Code == columnValuePair.Value).ToList();
                            break;

                        case "EGFR":
                            //EGFR Mutation Status
                            _tempCollection = _filteredtCollection.Where(x => x.EGFR_driver == columnValuePair.Value).ToList();
                            break;

                        case "KARNOFSKYSCORE":
                            //Karnofsky Performance Score
                            _tempCollection = _filteredtCollection.Where(x => x.Karnofsky_Performance_Score == columnValuePair.Value).ToList();
                            break;

                        case "SUBTYPE":
                            //Subtype
                            _tempCollection = _filteredtCollection.Where(x => x.Subtype == columnValuePair.Value).ToList();
                            break;
                        case "METASTASISSTAGECODE":
                        case "PRESENCEOFMETASTASIS":
                            //American Joint Committee on Cancer Metastasis Stage Code
                            _tempCollection = _filteredtCollection.Where(x => x.American_Joint_Committee_on_Cancer_Metastasis_Stage_Code == columnValuePair.Value).ToList();
                            break;

                        case "TUMORSTAGECODE":
                            //American Joint Committee on Cancer Tumor Stage Code
                            _tempCollection = _filteredtCollection.Where(x => x.American_Joint_Committee_on_Cancer_Tumor_Stage_Code == columnValuePair.Value).ToList();
                            break;

                        case "LYMPHNODESTAGECODE":
                            //Neoplasm Disease Lymph Node Stage American Joint Committee on Cancer Code
                            _tempCollection = _filteredtCollection.Where(x => x.Neoplasm_Disease_Lymph_Node_Stage_American_Joint_Committee_on_Cancer_Code == columnValuePair.Value).ToList();
                            break;

                        case "ECOG":
                            //ECOG
                            _tempCollection = _filteredtCollection.Where(x => x.ECOG == columnValuePair.Value).ToList();
                            break;

                        case "GENDER":
                            //Sex
                            _tempCollection = _filteredtCollection.Where(x => x.Sex == columnValuePair.Value).ToList();
                            break;

                        case "ALK":
                            //ALK Translocation Status
                            _tempCollection = _filteredtCollection.Where(x => x.ALK_Translocation_Status == columnValuePair.Value).ToList();
                            break;

                        default:
                            break;
                    }
                    if (_tempCollection.Count > 0)
                    {
                        _filteredtCollection = _tempCollection;
                    }

                }
            }
            return _filteredtCollection;
        }

        private List<KeyValuePair<string, string>> CreateMokData()
        {
            List<KeyValuePair<string, string>> prop =  new List<KeyValuePair<string, string>>();
            prop.Add(new KeyValuePair<string, string>("Age", "30")); 
            prop.Add(new KeyValuePair<string, string>("Stage", "STAGE III"));
            prop.Add(new KeyValuePair<string, string>("Tumor Stage code", "T1"));
            prop.Add(new KeyValuePair<string, string>("ECOG", "1"));
            prop.Add(new KeyValuePair<string, string>("Gender", "Male"));

            return prop;
        }

        public List<PatientRecords> GetListOfPatientsWithMatchingCriteria(object input)
        {
            List<KeyValuePair<string, string>> keyValuePairs = new List<KeyValuePair<string, string>>();
            //using (StreamReader r = new StreamReader(input))
            //{
            //    string json = r.ReadToEnd();
            //    var values = JsonSerializer.Deserialize<Dictionary<string, string>>(json).ToList();
            //}

            dynamic values = JsonSerializer.Deserialize<Dictionary<string, string>>(input.ToString());
            foreach (var item in values)
            {
                KeyValuePair<string, string> temp = new KeyValuePair<string, string>(item.Key, item.Value);  
              
                keyValuePairs.Add(temp);
            }
            return GetRecordsFilterBasedOnValue(keyValuePairs);
        }

        //public string GetListOfPatientsWithMatchingCriteria(string input)
        //{

        //    using (StreamReader r = new StreamReader(input))
        //    {
        //        string json = r.ReadToEnd();
        //        var values = JsonSerializer.Deserialize<Dictionary<string, string>>(json);
        //    }

        //    return string.Empty;
        //}


        public async Task RemoveAsync(string id) => await _patientRecordCollection.DeleteOneAsync(x => x.Patient_ID == id);
    }
}
