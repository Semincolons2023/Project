﻿using Amazon.Runtime.Internal.Transform;
using MongoDB.Bson.IO;
using OncologyDataScanner.Model;
using System.Text.Json;

namespace OncologyDataScanner.Utility
{
    public class DataMappingModel :IDataScanner
    {
        public string GetValidColomnNameAndValue(string col, string val)
        {
            Tuple<string, string> ColNameValue = GetMappingColumnName(col);
            string ColName = ColNameValue.Item1;
            string ColValue = ColNameValue.Item2;
            bool isValid = CheckIfColumnHasValidInputValue(ColValue, val);
            return string.Empty;
        }
        private Tuple<string, string> GetMappingColumnName(string inputName)
        {
            string columnVale = string.Empty;
            string columnName = string.Empty;
            string InputColumnName = System.Text.RegularExpressions.Regex.Replace(inputName, @"\s+", "").ToUpper();
            switch (InputColumnName)
            {
                case "AGEINT":
                case "AGE":
                    columnName = "Diagnosis Age";
                    columnVale = Utility.ColumnValues.Diagnosis_Age;
                    break;
                case "CANCERTYPE":
                    columnName = "Cancer Type";
                    columnVale = Utility.ColumnValues.Cancer_Type;

                    break;
                case "STAGE":
                    columnName = "Neoplasm Disease Stage American Joint Committee on Cancer Code";
                    columnVale = Utility.ColumnValues.Stage;
                    break;
                case "EGFR":
                    columnName = "EGFR Mutation Status";
                    columnVale = Utility.ColumnValues.EGFR_Mutation_status;
                    break;
                case "KARNOFSKYSCORE":
                    columnName = "Karnofsky Performance Score";
                    columnVale = Utility.ColumnValues.Karnofsky_Performance_Score;
                    break;
                case "SUBTYPE":
                    columnName = "Subtype";
                    columnVale = Utility.ColumnValues.Subtype;
                    break;
                case "METASTASISSTAGECODE":
                case "PRESENCEOFMETASTASIS":
                    columnName = "American Joint Committee on Cancer Metastasis Stage Code";
                    columnVale = Utility.ColumnValues.Metastasis_Stage_code;
                    break;
                case "TUMORSTAGECODE":
                    columnName = "American Joint Committee on Cancer Tumor Stage Code";
                    columnVale = Utility.ColumnValues.Tumor_Stage_Code;
                    break;
                case "LYMPHNODESTAGECODE":
                    columnName = "Neoplasm Disease Lymph Node Stage American Joint Committee on Cancer Code";
                    columnVale = Utility.ColumnValues.Lymph_Node_Stage_Code;
                    break;
                case "ECOG":
                    columnName = "ECOG";
                    columnVale = Utility.ColumnValues.ECOG;
                    break;
                case "GENDER":
                    columnName = "Sex";
                    columnVale = Utility.ColumnValues.Sex;
                    break;
                case "ALK":
                    columnName = "ALK Translocation Status";
                    columnVale = Utility.ColumnValues.ALK_Translocation_Status;
                    break;
                default:
                    columnName = string.Empty;
                    break;
            }
            return new Tuple<string, string>(columnName, columnVale.Trim());
        }

        private bool CheckIfColumnHasValidInputValue(string possibleValue, string inputValue)
        {
            bool result = false;
            int n;

            if (int.TryParse(possibleValue, out n))
            {
                if (Convert.ToInt32(inputValue) < n)
                {
                    result = true;
                }
            }
            else
            {
                if (possibleValue.Split(",").ToList().Any(x => x == inputValue))
                {
                    result = true;
                }
            }


            return result;
        }

        public string GetListOfPatientsWithMatchingCriteria(string input)
        {
            // List<KeyValuePair<string,string>> keyValuePairs= new List<KeyValuePair<string,string>>(input);

            using (StreamReader r = new StreamReader(@"D:\\Divyansh\\Oncology Semicolon\\CompleteData\\PatientRecordsClinicalData.json"))
            {
                string json = r.ReadToEnd();
                var values = JsonSerializer.Deserialize<Dictionary<string, string>>(input);
            }
           // var values = JsonSerializer.Deserialize<Dictionary<string, string>>(input);

            return string.Empty;
        }
    }


}
