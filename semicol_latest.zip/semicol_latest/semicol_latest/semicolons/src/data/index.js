const data = [{
    
    id: 1,
    icon: "⭕️",
    status: "Inclusion Criteria",
    title: " Age : 18 ",
    title1: "State : CA",
    content: "Demographics"
},{
    
    id:2,
    icon: "⭕️",
    status: "Inclusion Criteria",
    title: "Platinum chemotherapy",
    title1:"T cell Therapy",
    content: "Treatment History"
}, {
    
    id: 3,
    icon: "⭕️",
    status: "Inclusion Criteria",
    title: " Stage: III",
    
    content: "Pathology Report"
},{
    
    id: 4,
    icon: "🔆️",
    status: "Exclusion Criteria",
    title: " Age : 80 ",
    title1: "State : NY",
    content: "Demographics"
},{
    
    id:5,
    icon: "🔆️",
    status: "Exclusion Criteria",
    title: "Platinum chemotherapy",
    title1:"T cell Therapy",
    content: "Treatment History"
}, {
    
    id: 6,
    icon: "🔆️",
    status: "Exclusion Criteria",
    title: " Stage: III",
    
    content: "Pathology Report"
}, {
    
    id: 7,
    icon: "✅",
    status: "Uncategorized Criteria",
    title: "anti-PD-1 or PD-L1 therapies",
    title1: "Autoimmune Disease",
    
    content: "Treatment "}
];

const statuses = [{
    status: "Inclusion Criteria",
    icon: "⭕️",
    color: "#EB5A46"
}, {
    status: "Exclusion Criteria",
    icon: "🔆️",
    color: "#00C2E0"
}, {
    status: "Uncategorized Criteria",
    icon: "✅",
    color: "#3981DE"
}];

const points = data.map(item => {
    return {
        id: item.id,
        icon: item.icon,
        status: item.status,
        points: item.title.split('\n'),
        content: item.content
    }
});
export { data, statuses,points };
