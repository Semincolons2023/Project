#!/bin/sh
#execute script as root/sudo-user
sudo sh ubuntu.sh
