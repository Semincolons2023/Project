const ITEM_TYPE = "CARD";

export default ITEM_TYPE;