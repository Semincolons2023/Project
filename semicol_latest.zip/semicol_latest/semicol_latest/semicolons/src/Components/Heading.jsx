import React from "react";

function Heading() {
  return (
    <nav className="navbar sticky-top bg-body-tertiary">
      <div className="container-fluid">
        <span className="navbar-brand mb-0 h1">eTrial</span>
      </div>
    </nav>
  );
}

export default Heading;
