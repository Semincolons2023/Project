import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";

import Home from "./pages/Home";
import Heading from "./Components/Heading";
import Footer from "./Components/Footer";
import CategoryDND from "./pages/CategoryDND";

export default function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Heading />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/category" element={<CategoryDND />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}
