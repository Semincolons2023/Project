﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OncologyDataScanner.DatabaseService;
using OncologyDataScanner.Model;
using OncologyDataScanner.Utility;
using ChartControls;

namespace OncologyDataScanner.Controllers
{
    [Route("OncologyDataScanner/[controller]")]
    [ApiController]
    
    public class OncologyDataController : ControllerBase
    {
        private readonly PatientService _patientService;

        public OncologyDataController(PatientService patientService)
        {
            _patientService = patientService;
        }


        [HttpGet("GetRecordsWithConditions")]
        public List<PatientRecords> GetRecordsWithConditions(string condition)=> _patientService.GetListOfPatientsWithMatchingCriteria(condition);

        [HttpPost("GetRecordsWithConditions")]
        public List<PatientRecords> GetRecordsWithConditions1([FromBody]Object condition)
        {
            List<PatientRecords> result = _patientService.GetListOfPatientsWithMatchingCriteria(condition.ToString());
           
            return result;
        }

       

    }
}
