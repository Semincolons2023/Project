#!/bin/sh
#execute script as sudo-user(ubuntu-derivates only)
sudo sh ubuntSep.sh
