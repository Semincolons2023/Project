import React, { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import Category from "./Category";
import { DndProvider } from "react-dnd";
import { HTML5Backend } from 'react-dnd-html5-backend';
import axios from "axios";
//import json from "json5";


const CategoryDND = () => {
    const location = new useLocation();
    const [inclusionCriteria, setInclusionCriteria] = useState([]);
    const [exclusionCriteria, setExclusionCriteria] = useState([]);
    useEffect(() => {
        console.log("Hello");
        console.log(location);
        const criterias = { "criteria": [{ "inclusion" : location.state.iText }, { "exclusion":location.state.eText }]};
        setInclusionCriteria(location.state.iText);
        setExclusionCriteria(location.state.eText);
        axios.post("https://localhost:7036/OncologyDataScanner/OncologyData/GetRecordsWithConditions", criterias)
            .then(response => {
                console.log(response);
            })
            .catch(error => {
                console.log(error);
            }, []);
});
    return (
        <div className="container-fluid inclusionCriteria">
            <div className="row container-fluid">
                <div className="col-5">
                    <h1>Inclusion Criteria</h1>
                    {inclusionCriteria.map((val) => <li>{Object.keys(val)[0]}:{val[Object.keys(val)[0]]}</li> )}
                </div>
                <div className="col-5">
                    <h1>Exclusion Criteria</h1>
                    {exclusionCriteria.map((val) => <li>{Object.keys(val)[0]}:{val[Object.keys(val)[0]]}</li> )}</div>
            </div>
            <button>Next</button>
        </div>
    );
};

export default CategoryDND;


