#Install thing

# import dependencies

import spacy
from spacy.tokens import DocBin
from flask import Flask




nlp = spacy.blank("en")  # a new spacy model
db = DocBin() # a new DocBin object

#initialise
nlp_ner = spacy.load(".\model-best") 


app = Flask(__name__)

@app.route("/")
def GetTags(inclusion_text, exclusion_text):
    inlcusion_doc = nlp_ner(inclusion_text)
    exclusion_doc = nlp_ner(exclusion_text)
    inclusion_tags = []
    exclusion_tags = []
    
    for entity in inlcusion_doc.ents:
        inclusion_tags.append({entity.label_: entity.text})
    
    for entity in exclusion_doc.ents:
        exclusion_tags.append({entity.label_: entity.text})
    return [inclusion_tags, exclusion_tags]



