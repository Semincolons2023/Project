﻿namespace OncologyDataScanner.Model
{
    public class TimeLineData
    {
        public TimeLineData()
        {
            SampleAcquisition = new SampleAcquisition();
            Status = new List<Status>();
            Treatment = new List<Treatment>();
            Surgery = new List<Surgery>();
        }

        public SampleAcquisition SampleAcquisition { get; set; }
        public List<Status> Status { get; set; }
        public List<Treatment> Treatment { get; set; }

        public List<Surgery> Surgery { get; set; }
    }

    public class SampleAcquisition
    {
        public string START_DATE { get; set; } = String.Empty;

        public string STOP_DATE { get; set; } = String.Empty;

        public string EVENT_TYPE { get; set; } = String.Empty;

        public string TOP_SLIDE_SUBMITTED { get; set; } = String.Empty;

        public string TUMOR_NUCLEI_PERCENT { get; set; } = String.Empty;

        public string COUNTRY { get; set; } = String.Empty;

        public string VESSEL_USED { get; set; } = String.Empty;

        public string SAMPLE_PRESCREENED { get; set; } = String.Empty;

        public string TUMOR_WEIGHT { get; set; } = String.Empty;

        public string TUMOR_NECROSIS_PERCENT { get; set; } = String.Empty;

        public string SAMPLE_ID { get; set; } = String.Empty;

    }

    public class Status
    {
        public string START_DATE { get; set; } = String.Empty;
        public string STOP_DATE { get; set; } = String.Empty;
        public string EVENT_TYPE { get; set; } = String.Empty;
        public string PATHOLOGIC_STAGE { get; set; } = String.Empty;
        public string STATUS { get; set; } = String.Empty;
        public string SYSTEM_VERSION { get; set; } = String.Empty;
        public string PATHOLOGIC_T { get; set; } = String.Empty;
        public string PATHOLOGIC_N { get; set; } = String.Empty;
        public string PATHOLOGIC_M { get; set; } = String.Empty;
        public string TUMOR_STATUS { get; set; } = String.Empty;
        public string VITAL_STATUS { get; set; } = String.Empty;
        public string PRIMARY_THERAPY_OUTCOME_SUCCESS { get; set; } = String.Empty;
    }
    public class Treatment
    {
        public string START_DATE { get; set; } = String.Empty;
        public string STOP_DATE { get; set; } = String.Empty;
        public string EVENT_TYPE { get; set; } = String.Empty;
        public string AGENT { get; set; } = String.Empty;
        public string TREATMENT_TYPE { get; set; } = String.Empty;
        public string MEASURE_OF_RESPONSE { get; set; } = String.Empty;
        public string TX_ON_CLINICAL_TRIAL { get; set; } = String.Empty;
        public string THERAPY_ONGOING { get; set; } = String.Empty;
        public string ANATOMIC_TREATMENT_SITE { get; set; } = String.Empty;
        public string RADIATION_TREATMENT_ONGOING { get; set; } = String.Empty;
        public string RADIATION_TYPE { get; set; } = String.Empty;
        public string RADIATION_UNITS { get; set; } = String.Empty;
    }

    public class Surgery
    {
        public string START_DATE { get; set; } = String.Empty;
        public string STOP_DATE { get; set; } = String.Empty;
        public string EVENT_TYPE { get; set; } = String.Empty;
    }
}
