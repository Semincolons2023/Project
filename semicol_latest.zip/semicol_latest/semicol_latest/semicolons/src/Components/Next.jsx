import React from "react";
import { Link, useLocation } from "react-router-dom";
// import Navigation from "./Navigation";

function Next(props) {
  let location = useLocation();
  console.log(location.state);
  //console.log(this.props);
  const inclusion = location.state.iText;
  const exclusion = location.state.eText;
  return (
    <div>
      <div className="home">
        <div>
          <p>{inclusion}</p>
          <br />
          <p>{exclusion}</p>
          <button>
            <Link to="/">Home</Link>
          </button>
        </div>
      </div>
    </div>
  );
}

export default Next;
