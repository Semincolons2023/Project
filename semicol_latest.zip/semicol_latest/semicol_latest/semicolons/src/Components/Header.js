import React from "react";

const Header = () => {
    return (
        <div className={"row"}>
            <p className={"page-header"}>Semicolon🗂</p>
        </div>
    );
};

export default Header;