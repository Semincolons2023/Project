﻿using Microsoft.Extensions.Logging;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using static MongoDB.Bson.Serialization.Serializers.SerializerHelper;
using static System.Collections.Specialized.BitVector32;
using System.Data;
using System.Diagnostics;
using System.Text.Json.Serialization;
using System.Collections.Generic;
using ThirdParty.Json.LitJson;

namespace OncologyDataScanner.Model
{

    public class PatientRecords
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        [JsonIgnore]
        public ObjectId _id { get; set; } = ObjectId.Empty;
        [BsonElement("Study ID")][JsonPropertyName("Study ID")] public string Study_ID { get; set; } = String.Empty;
        [BsonElement("Patient ID")][JsonPropertyName("Patient ID")] public string Patient_ID { get; set; } = String.Empty;
        [BsonElement("Sample ID")][JsonPropertyName("Sample ID")] public string Sample_ID { get; set; } = String.Empty;
        [BsonElement("Diagnosis Age")][JsonPropertyName("Diagnosis Age")] public string Diagnosis_Age { get; set; } = String.Empty;
        [BsonElement("Neoplasm American Joint Committee on Cancer Clinical Distant Metastasis M Stage")][JsonPropertyName("Neoplasm American Joint Committee on Cancer Clinical Distant Metastasis M Stage")] public string Neoplasm_American_Joint_Committee_on_Cancer_Clinical_Distant_Metastasis_M_Stage { get; set; } = String.Empty;
        [BsonElement("American Joint Committee on Cancer Metastasis Stage Code")][JsonPropertyName("American Joint Committee on Cancer Metastasis Stage Code")] public string American_Joint_Committee_on_Cancer_Metastasis_Stage_Code { get; set; } = String.Empty;
        [BsonElement("American Joint Committee on Cancer Lymph Node Stage Code")][JsonPropertyName("American Joint Committee on Cancer Lymph Node Stage Code")] public string American_Joint_Committee_on_Cancer_Lymph_Node_Stage_Code { get; set; } = String.Empty;
        [BsonElement("Neoplasm Disease Lymph Node Stage American Joint Committee on Cancer Code")][JsonPropertyName("Neoplasm Disease Lymph Node Stage American Joint Committee on Cancer Code")] public string Neoplasm_Disease_Lymph_Node_Stage_American_Joint_Committee_on_Cancer_Code { get; set; } = String.Empty;
        [BsonElement("Neoplasm Disease Stage American Joint Committee on Cancer Code")][JsonPropertyName("Neoplasm Disease Stage American Joint Committee on Cancer Code")] public string Neoplasm_Disease_Stage_American_Joint_Committee_on_Cancer_Code { get; set; } = String.Empty;
        [BsonElement("American Joint Committee on Cancer Tumor Stage Code")][JsonPropertyName("American Joint Committee on Cancer Tumor Stage Code")] public string American_Joint_Committee_on_Cancer_Tumor_Stage_Code { get; set; } = String.Empty;
        [BsonElement("ALK Analysis Type")][JsonPropertyName("ALK Analysis Type")] public string ALK_Analysis_Type { get; set; } = String.Empty;
        [BsonElement("ALK Translocation Status")][JsonPropertyName("ALK Translocation Status")] public string ALK_Translocation_Status { get; set; } = String.Empty;
        [BsonElement("ALK Translocation Variant")][JsonPropertyName("ALK Translocation Variant")] public string ALK_Translocation_Variant { get; set; } = String.Empty;
        [BsonElement("Cancer Type")][JsonPropertyName("Cancer Type")] public string Cancer_Type { get; set; } = String.Empty;
        [BsonElement("Cancer Type Detailed")][JsonPropertyName("Cancer Type Detailed")] public string Cancer_Type_Detailed { get; set; } = String.Empty;
        [BsonElement("Carbon monoxide diffusion dlco")][JsonPropertyName("Carbon monoxide diffusion dlco")] public string Carbon_monoxide_diffusion_dlco { get; set; } = String.Empty;
        [BsonElement("Fraction Genome Altered")][JsonPropertyName("Fraction Genome Altered")] public string Fraction_Genome_Altered { get; set; } = String.Empty;
        [BsonElement("Year Cancer Initial Diagnosis")][JsonPropertyName("Year Cancer Initial Diagnosis")] public string Year_Cancer_Initial_Diagnosis { get; set; } = String.Empty;
        [BsonElement("Is FFPE")][JsonPropertyName("Is FFPE")] public string Is_FFPE { get; set; } = String.Empty;
        [BsonElement("Karnofsky Performance Score")][JsonPropertyName("Karnofsky Performance Score")] public string Karnofsky_Performance_Score { get; set; } = String.Empty;
        [BsonElement("KRAS Mutation")][JsonPropertyName("KRAS Mutation")] public string KRAS_Mutation { get; set; } = String.Empty;
        [BsonElement("Location lung parenchyma")][JsonPropertyName("Location lung parenchyma")] public string Location_lung_parenchyma { get; set; } = String.Empty;
        [BsonElement("Longest Dimension")][JsonPropertyName("Longest Dimension")] public string Longest_Dimension { get; set; } = String.Empty;
        [BsonElement("Mutation Count")][JsonPropertyName("Mutation Count")] public string Mutation_Count { get; set; } = String.Empty;
        [BsonElement("Mutation Status")][JsonPropertyName("Mutation Status")] public string Mutation_Status { get; set; } = String.Empty;
        [BsonElement("Mutation Type")][JsonPropertyName("Mutation Type")] public string Mutation_Type { get; set; } = String.Empty;
        [BsonElement("New Neoplasm Event Post Initial Therapy Indicator")][JsonPropertyName("New Neoplasm Event Post Initial Therapy Indicator")] public string New_Neoplasm_Event_Post_Initial_Therapy_Indicator { get; set; } = String.Empty;
        [BsonElement("Number of lymphnodes positive by ihc")][JsonPropertyName("Number of lymphnodes positive by ihc")] public string Number_of_lymphnodes_positive_by_ihc { get; set; } = String.Empty;
        [BsonElement("Oct embedded")][JsonPropertyName("Oct embedded")] public string Oct_embedded { get; set; } = String.Empty;
        [BsonElement("Oncotree Code")][JsonPropertyName("Oncotree Code")] public string Oncotree_Code { get; set; } = String.Empty;
        [BsonElement("Lymph node location positive pathology name")][JsonPropertyName("Lymph node location positive pathology name")] public string Lymph_node_location_positive_pathology_name { get; set; } = String.Empty;
        [BsonElement("Patient Primary Tumor Site")][JsonPropertyName("Patient Primary Tumor Site")] public string Patient_Primary_Tumor_Site { get; set; } = String.Empty;
        [BsonElement("Project code")][JsonPropertyName("Project code")] public string Project_code { get; set; } = String.Empty;
        [BsonElement("Race Category")][JsonPropertyName("Race Category")] public string Race_Category { get; set; } = String.Empty;
        [BsonElement("Number of Samples Per Patient")][JsonPropertyName("Number of Samples Per Patient")] public string Number_of_Samples_Per_Patient { get; set; } = String.Empty;
        [BsonElement("Sex")][JsonPropertyName("Sex")] public string Sex { get; set; } = String.Empty;
        [BsonElement("Somatic Status")][JsonPropertyName("Somatic Status")] public string Somatic_Status { get; set; } = String.Empty;
        [BsonElement("Adjuvant Postoperative Targeted Therapy Administered Indicator")][JsonPropertyName("Adjuvant Postoperative Targeted Therapy Administered Indicator")] public string Adjuvant_Postoperative_Targeted_Therapy_Administered_Indicator { get; set; } = String.Empty;
        [BsonElement("Tissue Source Site")][JsonPropertyName("Tissue Source Site")] public string Tissue_Source_Site { get; set; } = String.Empty;
        [BsonElement("TMB (nonsynonymous)")][JsonPropertyName("TMB (nonsynonymous)")] public string TMB_nonsynonymous { get; set; } = String.Empty;
        [BsonElement("Tumor Site")][JsonPropertyName("Tumor Site")] public string Tumor_Site { get; set; } = String.Empty;
        [BsonElement("Person Neoplasm Status")][JsonPropertyName("Person Neoplasm Status")] public string Person_Neoplasm_Status { get; set; } = String.Empty;
        [BsonElement("Vial number")][JsonPropertyName("Vial number")] public string Vial_number { get; set; } = String.Empty;
        [BsonElement("Aneuploidy Score")][JsonPropertyName("Aneuploidy Score")] public string Aneuploidy_Score { get; set; } = String.Empty;
        [BsonElement("Buffa Hypoxia Score")][JsonPropertyName("Buffa Hypoxia Score")] public string Buffa_Hypoxia_Score { get; set; } = String.Empty;
        [BsonElement("TCGA PanCanAtlas Cancer Type Acronym")][JsonPropertyName("TCGA PanCanAtlas Cancer Type Acronym")] public string TCGA_PanCanAtlas_Cancer_Type_Acronym { get; set; } = String.Empty;
        [BsonElement("Disease_specific Survival status")][JsonPropertyName("Disease_specific Survival status")] public string Disease_specific_Survival_status { get; set; } = String.Empty;
        [BsonElement("Neoplasm Histologic Grade")][JsonPropertyName("Neoplasm Histologic Grade")] public string Neoplasm_Histologic_Grade { get; set; } = String.Empty;
        [BsonElement("In PanCan Pathway Analysis")][JsonPropertyName("In PanCan Pathway Analysis")] public string In_PanCan_Pathway_Analysis { get; set; } = String.Empty;
        [BsonElement("MSI MANTIS Score")][JsonPropertyName("MSI MANTIS Score")] public string MSI_MANTIS_Score { get; set; } = String.Empty;
        [BsonElement("MSIsensor Score")][JsonPropertyName("MSIsensor Score")] public string MSIsensor_Score { get; set; } = String.Empty;
        [BsonElement("Person Neoplasm Cancer Status")][JsonPropertyName("Person Neoplasm Cancer Status")] public string Person_Neoplasm_Cancer_Status { get; set; } = String.Empty;
        [BsonElement("Progression Free Status")][JsonPropertyName("Progression Free Status")] public string Progression_Free_Status { get; set; } = String.Empty;
        [BsonElement("Primary Lymph Node Presentation Assessment")][JsonPropertyName("Primary Lymph Node Presentation Assessment")] public string Primary_Lymph_Node_Presentation_Assessment { get; set; } = String.Empty;
        [BsonElement("Radiation Therapy")][JsonPropertyName("Radiation Therapy")] public string Radiation_Therapy { get; set; } = String.Empty;
        [BsonElement("Ragnum Hypoxia Score")][JsonPropertyName("Ragnum Hypoxia Score")] public string Ragnum_Hypoxia_Score { get; set; } = String.Empty;
        [BsonElement("Subtype")][JsonPropertyName("Subtype")] public string Subtype { get; set; } = String.Empty;
        [BsonElement("Tissue Prospective Collection Indicator")][JsonPropertyName("Tissue Prospective Collection Indicator")] public string Tissue_Prospective_Collection_Indicator { get; set; } = String.Empty;
        [BsonElement("Tissue Retrospective Collection Indicator")][JsonPropertyName("Tissue Retrospective Collection Indicator")] public string Tissue_Retrospective_Collection_Indicator { get; set; } = String.Empty;
        [BsonElement("Tissue Source Site Code")][JsonPropertyName("Tissue Source Site Code")] public string Tissue_Source_Site_Code { get; set; } = String.Empty;
        [BsonElement("Tumor Disease Anatomic Site")][JsonPropertyName("Tumor Disease Anatomic Site")] public string Tumor_Disease_Anatomic_Site { get; set; } = String.Empty;
        [BsonElement("Tumor Type")][JsonPropertyName("Tumor Type")] public string Tumor_Type { get; set; } = String.Empty;
        [BsonElement("Patient Weight")][JsonPropertyName("Patient Weight")] public string Patient_Weight { get; set; } = String.Empty;
        [BsonElement("Winter Hypoxia Score")][JsonPropertyName("Winter Hypoxia Score")] public string Winter_Hypoxia_Score { get; set; } = String.Empty;
        [BsonElement("Distant Metastasis Pathologic Spread")][JsonPropertyName("Distant Metastasis Pathologic Spread")] public string Distant_Metastasis_Pathologic_Spread { get; set; } = String.Empty;
        [BsonElement("Tumor Other Histologic Subtype")][JsonPropertyName("Tumor Other Histologic Subtype")] public string Tumor_Other_Histologic_Subtype { get; set; } = String.Empty;
        [BsonElement("Primary Tumor Pathologic Spread")][JsonPropertyName("Primary Tumor Pathologic Spread")] public string Primary_Tumor_Pathologic_Spread { get; set; } = String.Empty;
        [BsonElement("BOR")][JsonPropertyName("BOR")] public string BOR { get; set; } = String.Empty;
        [BsonElement("CT scan type")][JsonPropertyName("CT scan type")] public string CT_scan_type { get; set; } = String.Empty;
        [BsonElement("Impact TMB Percentile (Across All Tumor Types)")][JsonPropertyName("Impact TMB Percentile (Across All Tumor Types)")] public string Impact_TMB_Percentile_Across_All_Tumor_Types { get; set; } = String.Empty;
        [BsonElement("Impact TMB Score")][JsonPropertyName("Impact TMB Score")] public string Impact_TMB_Score { get; set; } = String.Empty;
        [BsonElement("Cytology fixation type")][JsonPropertyName("Cytology fixation type")] public string Cytology_fixation_type { get; set; } = String.Empty;
        [BsonElement("Durable clinical response")][JsonPropertyName("Durable clinical response")] public string Durable_clinical_response { get; set; } = String.Empty;
        [BsonElement("Disease")][JsonPropertyName("Disease")] public string Disease { get; set; } = String.Empty;
        [BsonElement("dNLR")][JsonPropertyName("dNLR")] public string dNLR { get; set; } = String.Empty;
        [BsonElement("ECOG")][JsonPropertyName("ECOG")] public string ECOG { get; set; } = String.Empty;
        [BsonElement("EGFR driver")][JsonPropertyName("EGFR driver")] public string EGFR_driver { get; set; } = String.Empty;
        [BsonElement("EGFR protein change")][JsonPropertyName("EGFR protein change")] public string EGFR_protein_change { get; set; } = String.Empty;
        [BsonElement("ERBB2 driver")][JsonPropertyName("ERBB2 driver")] public string ERBB2_driver { get; set; } = String.Empty;
        [BsonElement("Gene Panel")][JsonPropertyName("Gene Panel")] public string Gene_Panel { get; set; } = String.Empty;
        [BsonElement("Halo tumor quality score")][JsonPropertyName("Halo tumor quality score")] public string Halo_tumor_quality_score { get; set; } = String.Empty;
        [BsonElement("Histology")][JsonPropertyName("Histology")] public string Histology { get; set; } = String.Empty;
        [BsonElement("Institute Source")][JsonPropertyName("Institute Source")] public string Institute_Source { get; set; } = String.Empty;
        [BsonElement("IO drug name")][JsonPropertyName("IO drug name")] public string IO_drug_name { get; set; } = String.Empty;
        [BsonElement("Line of therapy")][JsonPropertyName("Line of therapy")] public string Line_of_therapy { get; set; } = String.Empty;
        [BsonElement("Manual tumor annotation")][JsonPropertyName("Manual tumor annotation")] public string Manual_tumor_annotation { get; set; } = String.Empty;
        [BsonElement("Metastatic Site")][JsonPropertyName("Metastatic Site")] public string Metastatic_Site { get; set; } = String.Empty;
        [BsonElement("MET driver")][JsonPropertyName("MET driver")] public string MET_driver { get; set; } = String.Empty;
        [BsonElement("MET protein change")][JsonPropertyName("MET protein change")] public string MET_protein_change { get; set; } = String.Empty;
        [BsonElement("MGMT Status")][JsonPropertyName("MGMT Status")] public string MGMT_Status { get; set; } = String.Empty;
        [BsonElement("MSI Score")][JsonPropertyName("MSI Score")] public string MSI_Score { get; set; } = String.Empty;
        [BsonElement("MSI Type")][JsonPropertyName("MSI Type")] public string MSI_Type { get; set; } = String.Empty;
        [BsonElement("MSK Slide ID")][JsonPropertyName("MSK Slide ID")] public string MSK_Slide_ID { get; set; } = String.Empty;
        [BsonElement("MSK Pathology Slide Available")][JsonPropertyName("MSK Pathology Slide Available")] public string MSK_Pathology_Slide_Available { get; set; } = String.Empty;
        [BsonElement("PD_L1 tissue site")][JsonPropertyName("PD_L1 tissue site")] public string PD_L1_tissue_site { get; set; } = String.Empty;
        [BsonElement("RET driver")][JsonPropertyName("RET driver")] public string RET_driver { get; set; } = String.Empty;
        [BsonElement("RET protein change")][JsonPropertyName("RET protein change")] public string RET_protein_change { get; set; } = String.Empty;
        [BsonElement("Status")][JsonPropertyName("Status")] public string Status { get; set; } = String.Empty;
        [BsonElement("TMB")][JsonPropertyName("TMB")] public string TMB { get; set; } = String.Empty;
        [BsonElement("Tumor Purity")][JsonPropertyName("Tumor Purity")] public string Tumor_Purity { get; set; } = String.Empty;
        [BsonElement("Treatment Setting")][JsonPropertyName("Treatment Setting")] public string Treatment_Setting { get; set; } = String.Empty;
        [BsonElement("WHO Grade")][JsonPropertyName("WHO Grade")] public string WHO_Grade { get; set; } = String.Empty;
        [BsonElement("Collaboration Id")][JsonPropertyName("Collaboration Id")] public string Collaboration_Id { get; set; } = String.Empty;
        [BsonElement("M Stage")][JsonPropertyName("M Stage")] public string M_Stage { get; set; } = String.Empty;
        [BsonElement("N Stage")][JsonPropertyName("N Stage")] public string N_Stage { get; set; } = String.Empty;
        [BsonElement("Overall Survival Days")][JsonPropertyName("Overall Survival Days")] public string Overall_Survival_Days { get; set; } = String.Empty;
        [BsonElement("Pre_treated")][JsonPropertyName("Pre_treated")] public string Pre_treated { get; set; } = String.Empty;
        [BsonElement("Procedure Type")][JsonPropertyName("Procedure Type")] public string Procedure_Type { get; set; } = String.Empty;
        [BsonElement("Stage At Diagnosis")][JsonPropertyName("Stage At Diagnosis")] public string Stage_At_Diagnosis { get; set; } = String.Empty;
        [BsonElement("Tissue Site")][JsonPropertyName("Tissue Site")] public string Tissue_Site { get; set; } = String.Empty;
        [BsonElement("T Stage")][JsonPropertyName("T Stage")] public string T_Stage { get; set; } = String.Empty;
        [BsonElement("Loss of Heterozygosity in Human Leukocyte Antigen")][JsonPropertyName("Loss of Heterozygosity in Human Leukocyte Antigen")] public string Loss_of_Heterozygosity_in_Human_Leukocyte_Antigen { get; set; } = String.Empty;
        [BsonElement("Mean Target Coverage Normal")][JsonPropertyName("Mean Target Coverage Normal")] public string Mean_Target_Coverage_Normal { get; set; } = String.Empty;
        [BsonElement("Mean Target Coverage Tumor")][JsonPropertyName("Mean Target Coverage Tumor")] public string Mean_Target_Coverage_Tumor { get; set; } = String.Empty;
        [BsonElement("Subclonal Mutation Ratio")][JsonPropertyName("Subclonal Mutation Ratio")] public string Subclonal_Mutation_Ratio { get; set; } = String.Empty;
        [BsonElement("Numer of Reads Per Tumor Chromosomal Copy")][JsonPropertyName("Numer of Reads Per Tumor Chromosomal Copy")] public string Numer_of_Reads_Per_Tumor_Chromosomal_Copy { get; set; } = String.Empty;
        [BsonElement("SCNA Cluster")][JsonPropertyName("SCNA Cluster")] public string SCNA_Cluster { get; set; } = String.Empty;
        [BsonElement("Tumor Grade")][JsonPropertyName("Tumor Grade")] public string Tumor_Grade { get; set; } = String.Empty;
        [BsonElement("Tumor Ploidy")][JsonPropertyName("Tumor Ploidy")] public string Tumor_Ploidy { get; set; } = String.Empty;
        [BsonElement("Tumor Stage")][JsonPropertyName("Tumor Stage")] public string Tumor_Stage { get; set; } = String.Empty;
        [BsonElement("Neoplasm American Joint Committee on Cancer Clinical Group Stage")][JsonPropertyName("Neoplasm American Joint Committee on Cancer Clinical Group Stage")] public string Neoplasm_American_Joint_Committee_on_Cancer_Clinical_Group_Stage { get; set; } = String.Empty;
        [BsonElement("Treatment Response")][JsonPropertyName("Treatment Response")] public string Treatment_Response { get; set; } = String.Empty;

        [BsonElement("TimeLineData")][JsonPropertyName("TimeLineData")] public TimeLineData TimeLineData { get; set; } = new TimeLineData();

    }

    

}
