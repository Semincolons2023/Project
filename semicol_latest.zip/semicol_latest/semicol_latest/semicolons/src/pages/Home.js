import React, { useState, useEffect } from "react";
import { createBrowserRouter, Link } from "react-router-dom";
//import ReactFileReader from "react-file-reader";
import axios from "axios";
// import Navigation from "./Navigation";

function Home() {
  const [inclusionText, setInclusionText] = useState("");
  const [exclusionText, setExclusionText] = useState("");
  const [pdfFile,setPdfFile]=useState("");
  const [fileData, setFileData] = useState();
  const [icText, setIcText] = useState([]);
  const [ecText, setEcText] = useState([]);
 
  useEffect(() => {
    const inclusionTextObj={text:inclusionText}
    const exclusionTextObj={text:exclusionText}
    axios.post('http://127.0.0.1:5000/criteriaExtractor', inclusionTextObj)
      .then(response => {
        //console.log(response.data);
        axios.post('http://127.0.0.1:5000/criteriaExtractor', exclusionTextObj).then(res => {
          setIcText(response.data);
          setEcText(res.data);
        }).catch(error => {
          console.log(error);
        });
        
      }).catch(err => {
      console.log(err);
      })
  });

  const fileChangeHandler = (e) => {
    setFileData(e.target.files[0]);
  };

  const onSubmitHandler = (cb) => {
    // Handle File Data from the state Before Sending
    const fileReader = new FileReader();
    fileReader.readAsDataURL(fileData);
    // data.append("users", fileData);
    fileReader.onload = function () {
      console.log(fileReader);
      console.log(fileReader.result);
      setPdfFile(fileReader.result);
      cb(null, pdfFile);
    }
  };

  function handleFileSubmit(e) {
    e.preventDefault();
    onSubmitHandler((e,result) => {
      const pdfString = result.substring(result.indexOf("base64,")+7,result.length);
      console.log(pdfString);
    const pdfFile = { pdfFile: pdfString };
    console.log(result);
      console.log(pdfString);
      console.log("Pdf Extractor");
      axios.post('http://127.0.0.1:5000/pdfExtractor',pdfFile)
        .then(response => {
          console.log(response.data);
          const modifiedInclusionText = response.data[0].INCLUSIONCRITERIA.replace("Inclusion Criteria :   \n ", "");
          const modifiedExclusionText = response.data[1].EXCLUSIONCRITERIA.replace("Exclusion Criteria :   \n", "");
          setInclusionText(modifiedInclusionText);
          setExclusionText(modifiedExclusionText);
        })
        .catch(error => console.log(error));
    });
  }
  function nextSubmit(e) {
    e.preventDefault();
    //setNewClick(true);
    //Link.to("/category");
  }

  return (
    <div className="container-fluid">
      <div className="container-fluid">
        <div className="input-group row p-3 container-fluid inclusionCriteria">
          <span className="input-group-text">Inclusion Criteria</span>
          <textarea
            className="form-control"
            aria-label="With textarea"
            onChange={(event) => {
              setInclusionText(event.target.value);
            }}
            value={inclusionText}
          ></textarea>
          <br />
        </div>
        <div className="input-group row p-3 container-fluid">
          <span className="input-group-text">Exclusion Criteria</span>
          <textarea
            className="form-control"
            aria-label="With textarea"
            onChange={(event) => {
              setExclusionText(event.target.value);
            }}
            value={exclusionText}
          ></textarea>
        </div>
        <div className="row p-3 container-fluid">
          <div className="col-8">
          <form onSubmit={handleFileSubmit}>
        <input type="file" onChange={fileChangeHandler} />
        <button type="submit">Upload</button>
      </form>
          </div>
          <div className="col-4">
            <button
              type="submit"
              className="btn btn-sm btn-primary"
              onClick={nextSubmit}
            >
              <Link to="/category" state={{ iText: icText, eText:ecText }} className="btn btn-sm btn-primary">Next</Link>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;
